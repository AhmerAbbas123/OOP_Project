/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.librarymanagementsystem;

public class Librarian {
    String name;
    String Employee_id;
    public Librarian(String name,String Employee_id){
        this.name=name;
        this.Employee_id=Employee_id;
    }
}
