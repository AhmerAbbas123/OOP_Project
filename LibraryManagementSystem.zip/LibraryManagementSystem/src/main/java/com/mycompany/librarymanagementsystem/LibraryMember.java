package com.mycompany.librarymanagementsystem;
import java.util.ArrayList;
public class LibraryMember {
    String name;
    String membership_id;
    ArrayList<Book> borrowedBook;
    public LibraryMember(String name,String membership_id,ArrayList<Book> borrowedBook){
        this.name=name;
        this.membership_id=membership_id;
        this.borrowedBook=borrowedBook;
        
    }

    
}
