

package com.mycompany.librarymanagementsystem;
import java.util.ArrayList;
import java.util.Scanner;
public class LibraryManagementSystem {
static void addBook(ArrayList<Book> ListBook){
    Scanner sc =new Scanner(System.in);
    System.out.println("Book title: ");
    String title=sc.next();
    System.out.println("Book author");
    String author=sc.next();
    System.out.println("Book genre");
    String genre=sc.next();
    Book b1=new Book(title,author,genre);
    ListBook.add(b1);}
public static void seeBook(ArrayList<Book> ListBook){
        for(int i=0;i<ListBook.size();i++)
        {
            System.out.println((i+1)+"\t"+ListBook.get(i)+"\t");}
}
static void removeBook(ArrayList<Book> ListBook){
    seeBook(ListBook);
     Scanner sc =new Scanner(System.in);
    System.out.println("Enter the number through which you want to delete book: ");
    int number=sc.nextInt();
    ListBook.remove(number-1);
    
}
static void borrowBook(ArrayList<Book> ListBook,ArrayList<Book> borrowedBook){
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter Your Name: ");
    String name=sc.nextLine();
    System.out.println("Enter your id: ");
    String id=sc.nextLine();
    
    seeBook(ListBook);
    System.out.println("Enter your choice: ");
    int number=sc.nextInt();
    borrowedBook.add(ListBook.get(number-1));
    LibraryMember b2=new LibraryMember(name,id,borrowedBook);  
}
static void returnBook(ArrayList<Book> borrowedBook){
    Scanner sc=new Scanner(System.in);
    seeBook(borrowedBook);
    int number;
    System.out.println("Enter your choise: ");
    number=sc.nextInt();
    borrowedBook.remove(number-1);
}

  

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        ArrayList<Book> borrowedBook=new ArrayList();
        ArrayList<Book> ListBook=new ArrayList();
        int number=0;
        do{
            System.out.print("\n1.Add Book\n2.See Book\n3.Remove Book\n4.Borrow Book\n5.Return Book\nEnter your Choice:");
            number=sc.nextInt();
            switch(number){
            case 1:
                addBook(ListBook);
                break;
            case 2:
                seeBook(ListBook);
                break;
            case 3:
                removeBook(ListBook);
                break;
            case 4:
                borrowBook(ListBook,borrowedBook);
                break;
            case 5:
                returnBook(borrowedBook);
                break;
            default:
                System.out.println("Your choise is wrong");
                
        }
        }while(number!=6);
    }
}
